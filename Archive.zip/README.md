# calculator

1. Create HTML, CSS and JavaScript files.

2. GitHub. Clone down repo.

3. Components of calculator:
   i) Calculator container
   ii) Display
   ii) Number keys
   iii) Operator keys
   iv) A/C or clear key

4. Requirements:
   i) A basic calculator that can add, multiply, subtract and divide numbers, including decimals.

5. CSS- Use grid to make keys/ background image (SVG)/ colours/ drop shadowing etc.

6. HTML- create structure that interacts with JavaScript functionality.

7. JavaScript:

i) Create functions for operators. eg. multiply, divide, substract and divide.
